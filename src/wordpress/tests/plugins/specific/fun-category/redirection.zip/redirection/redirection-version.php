<?php

define( 'REDIRECTION_VERSION', '2.10' );
define( 'REDIRECTION_BUILD', '8e27b3cfa35557a3724d6e5ad079097d' );
define( 'REDIRECTION_MIN_WP', '4.4' );
