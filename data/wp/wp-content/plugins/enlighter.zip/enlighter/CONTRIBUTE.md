Contribution
------------

Enlighter is OpenSource and managed on [GitHub](https://github.com/EnlighterJS/Plugin.WordPress) - if you like, you're welcome to contribute!
To simplify the release and quality control process, please follow these remarks:

### Notices ###
* Related software packages are updated by the maintainer (EnlighterJS, EnlighterJS.TinyMCE, Mootools, and so on)
* If you form a concept of larger project changes, please [discuss](https://github.com/EnlighterJS/Plugin.WordPress/issues) them with the contributors **before** implementing