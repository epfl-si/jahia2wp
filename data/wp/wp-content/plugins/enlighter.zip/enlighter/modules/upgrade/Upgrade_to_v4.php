<?php

namespace Enlighter\upgrade;

class Upgrade_to_v4{

    public function __construct(){
    }

    public function run($currentVersion, $newVersion){

    }

}