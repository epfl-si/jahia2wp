<?php

namespace Enlighter\customizer;

class Fonts{

    // font styles
    public static function customize($config, $css){

    }
}