<?php

/* Copy and modify this file to site.php to tweak this plugin for your site. */

namespace EPFL\Accred;

if (! defined('ABSPATH')) {
    die('Access denied.');
}

// Controller::getInstance()->is_debug_enabled = true;
// Controller::getInstance()->settings->is_debug_enabled = true;

// Uncomment to lock down the EPFL-Accred settings page to the user-serviceable
// parts only, as per VPSI policy.
// Controller::getInstance()->settings->vpsi_lockdown = true;
