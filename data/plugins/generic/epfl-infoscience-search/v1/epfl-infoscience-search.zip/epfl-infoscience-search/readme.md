# what not respected at the moment from infoscience-export

## not advanced show
- short format show only direct info
- detail show all (like volume, number, page)
- no bullets
- search is done only for publications from Infoscience/Published (no pending option)